function ProductCard({ name, price }) {
  return (
    <div style={{border:'1px solid #000', margin:'10px', padding:'10px'}}>
      <h2>{name}</h2>
      <p>₹{price}</p>
    </div>
  );
}
export default ProductCard;
