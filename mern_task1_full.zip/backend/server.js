const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://127.0.0.1:27017/mernTaskDB")
.then(()=>console.log("MongoDB Connected"))
.catch(err=>console.log(err));

const Product = mongoose.model("Product", {
  name: String,
  price: Number
});

app.get("/api/products", async (req, res) => {
  const data = await Product.find();
  res.json(data);
});

app.listen(5000, () => console.log("Server running on port 5000"));
